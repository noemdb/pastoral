<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreBmessegeRequest;
use App\Http\Requests\UpdateBmessegeRequest;
use App\Models\app\Bot\Bmessege;

class BmessegeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreBmessegeRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreBmessegeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\app\Bot\Bmessege  $bmessege
     * @return \Illuminate\Http\Response
     */
    public function show(Bmessege $bmessege)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\app\Bot\Bmessege  $bmessege
     * @return \Illuminate\Http\Response
     */
    public function edit(Bmessege $bmessege)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateBmessegeRequest  $request
     * @param  \App\Models\app\Bot\Bmessege  $bmessege
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateBmessegeRequest $request, Bmessege $bmessege)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\app\Bot\Bmessege  $bmessege
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bmessege $bmessege)
    {
        //
    }
}
