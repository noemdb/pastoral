<?php

namespace Database\Factories\app\Bot;

use Illuminate\Database\Eloquent\Factories\Factory;

class BmessegeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
