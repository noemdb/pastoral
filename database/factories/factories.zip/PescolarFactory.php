<?php

namespace Database\Factories\app;

use Illuminate\Database\Eloquent\Factories\Factory;

class PescolarFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
