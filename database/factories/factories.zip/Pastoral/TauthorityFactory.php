<?php

namespace Database\Factories\app\Pastoral;

use Illuminate\Database\Eloquent\Factories\Factory;

class TauthorityFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
